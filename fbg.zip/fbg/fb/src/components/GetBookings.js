import React, { Component } from "react";
import axios from "axios";
import Redirect from "../../node_modules/react-router-dom/Redirect";

const url = "http://localhost:1050/getAllBookings/";
const url1 = "http://localhost:1050/deleteBooking/";

class GetBooking extends Component {
  constructor(props) {
    super(props);
    this.state = {
      bookingData: "",
      bookingId: "",
      updateStatus: false,
      errorMessage: "",
      successMessage: ""
    };
  }

  componentDidMount() {
    this.fetchBooking();
  }

  // fetchBookingbyID = () => {
  //   axios.get(url + this.state.bookingId)
  //     .then(response => this.setState({ bookingData: response.data, errorMessage: "" }))
  //     .catch(error => {
  //       if (error.response.status === 404) {
  //         this.setState({
  //           errorMessage: "Booking Id " + this.state.bookingId + " not found.",
  //           bookingData: ""
  //         });
  //       } else {
  //         this.setState({ errorMessage: error.message, bookingData: "" });
  //       }
  //     });
  // }

  updateBooking = (bid) => {
    this.setState({ updateStatus: true, bookingId: bid });
  }

  fetchBooking = () => {
    axios.get(url)
      .then(response => this.setState({ bookingData: response.data, errorMessage: null }))
      .catch(error => {
        if (error.status === 404) {
          this.setState({ errorMessage: error.response.data.message, bookingData: null })
        } else {
          this.setState({ errorMessage: "Could not fetch booking data", bookingData: null })
        }
      })
  }

  deleteBooking = (id) => {
    axios.delete(url1 + id)
      .then(response => {
        this.setState({ successMessage: response.data.message, errorMessage: "" });
        setTimeout(() => {
          this.fetchBooking();
          this.setState({ successMessage: "", errorMessage: "" })
        }, 2000)
      }).catch(error => this.setState({ errorMessage: error.response.data.message, successMessage: "" }));
  }

  render() {
    const { bookingData } = this.state;
    var redirect = null;
    if (this.state.updateStatus) {
      redirect = <Redirect to={"/updateBooking/" + this.state.bookingId} push></Redirect>
    }

    return (
      <div className="GetBooking">
        <div className="row">
          <div className="col-md-6 offset-md-3">
            <br />
            <div className="card">
              <div className="card-header bg-custom">
                <h3 align="center">Booking Details</h3>
              </div>
              <div className="card-body">
                <div className="form-group">
                  {bookingData ? (
                    <div>
                      <table className="table table-bordered">
                        <thead>
                          <tr>
                            <th>Customer Id</th>
                            <th>Booking Id</th>
                            <th>Total Tickets</th>
                            <th>Total Cost</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody align="center">
                          {this.state.bookingData.map(item => (
                            <tr key={item.bookingId}>
                              <td>{item.customerId}</td>
                              <td>{item.bookingId}</td>
                              <td>{item.noOfTickets}</td>
                              <td>{item.bookingCost}</td>
                              <td>
                                <button value={item.bookingId} className="btn btn-success" onClick={(event) => this.updateBooking(event.target.value)}>Update</button>
                                &nbsp; &nbsp;
                                <button value={item.bookingId} className="btn btn-danger" onClick={(event) => this.deleteBooking(event.target.value)}>Cancel</button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : null}
                </div>
                <div align="center">
                  <span name="successMessage" className="text text-success">{this.state.successMessage}</span>
                  <span name="errorMessage" className="text text-danger">{this.state.errorMessage}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {redirect}
      </div>
    );
  }
}

export default GetBooking;
