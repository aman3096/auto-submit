const user = {}
const vscode = require('vscode');
const fs = require('fs-extra');
const zipFolder = require('zip-folder');
const path = require('path');
const info = require('./nodeApp');
const vm = require('vm');
const username = require("os").userInfo().username;
const desk_path = 'C:/Users/' + username + '/Desktop/';
const comp = desk_path + '/smooth-wheelz/src';
const { exec } = require('child_process');
var errors = 0;
var empties = 0;

user.logged = function (empId) {
	vscode.window.showInformationMessage("Submitting for " + username + " at " + 'C:/Users/' + username + '/Desktop/' + empId, ...['Backup', 'Submit'])
		.then((selection) => {
			if (selection == "Backup") {
				backup(empId);
			}
			else if (selection == "Submit") {
				info.putInfo(empId).then(_ => { vscode.window.showInformationMessage(_) });
				submit(empId);
			}
		})
};

const checkError = function (data, file) {
	data = String(data)
	try {
		const script = new vm.Script(data)
	}
	catch (e) {
		// vscode.window.showErrorMessage("Compilation error found at " + file)
		errors += 1;
		fs.appendFileSync(desk_path + '/Logs/errors.txt', file + '\r\n');
		asd();
	}
};

const checkErrorFiles = function (comp) {
	let arr = []
	fs.readdir(comp, (err, list) => {
		if (err) {
			console.log(err)
			vscode.window.showErrorMessage("Could not read directory\n" + err);
			return false;
		}
		list.forEach(element => {
			if (!(element.substr(-3) == "txt")) {
				arr.push(element);
			}
		})
		arr.forEach((file) => {
			file = path.resolve(comp, file);
			fs.stat(file, (err, stat) => {
				if (stat && stat.isDirectory()) {
					user.checkErrorFiles(file);
				}
				else {
					fs.readFile(file, 'utf-8', (err, data) => {
						checkError(data, file);
					})
				}
			})
		})
	})
};
 
const checkEmptyFiles = function (directoryPath) {
	//let flag = true;
	fs.readdir(directoryPath, (err, list) => {
		if (err) {
			console.log(err)
			vscode.window.showErrorMessage("Could not read directory\n" + err);
			return false;
		}
		list.forEach((file) => {
			file = path.resolve(directoryPath, file);
			fs.stat(file, (err, stat) => {
				if (stat && stat.isDirectory()) {
					checkEmptyFiles(file);
				}
				else {
					fs.readFile(file, 'utf-8', (err, data) => {
						if (data == "") {
							fs.appendFileSync(desk_path + '/Logs/errors.txt', file + '\r\n');
							empties += 1;
							// vscode.window.showErrorMessage("Empty File found at " + file);
							// flag = false;
						}
					})
				}
			})
		})
	})
	// flag
};

const backup = function (empId) {
	fs.writeFileSync(desk_path + '/Logs/errors.txt', '');
	fs.writeFileSync(desk_path + '/Logs/empties.txt', '');
	checkEmptyFiles(comp);
	checkErrorFiles(comp);
	vscode.window.showWarningMessage("A log of errorful and empty files can be found in the '/Logs' folder.")
	fs.copy
		(
			comp,
			desk_path + empId + '/src',
			err => {
				if (err) return console.error(err);
				else {
					zipFolder
						(
							desk_path + empId,
							desk_path + empId + '.zip',
							err => {
								if (err)
									vscode.window.showErrorMessage("Could not zip the folder!" + err);
							}
						);
				}
			}
		);
	vscode.window.showInformationMessage("Backed up successfully at " + desk_path + empId, ...['Submit']).then((selection) => {
		if (selection == "Submit") {
			submit(empId);
		}
	})
};

const submit = function (empId) {
	if (!fs.existsSync(desk_path + empId)) {
		vscode.window.showWarningMessage("No Backup found. Want to take Backup first?", ...['Backup'])
			.then((selection) => {
				if (selection == "Backup") {
					backup(empId);
				}
			})
	}
	else {
		// info.putInfo(empId).then(_ => { vscode.window.showInformationMessage(_) });
		vscode.window.showWarningMessage("Starting reactApp..." + " This might take a few minutes.");
		process.chdir(desk_path + "/js ex demo/2nd-extension/reactApp/src")
		const child = exec('npm start', ['index.js'], (err, stdout, stderr) => {
			if (err) {
				vscode.window.showInformationMessage("Submission successful")
			}
		});
	}
};

module.exports = user;
