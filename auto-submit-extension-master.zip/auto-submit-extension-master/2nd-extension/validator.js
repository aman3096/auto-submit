const validator={}
const vscode = require ('vscode');

validator.validateEmpId = function (empId) {
	if (empId !== undefined && empId.length > 0) {
		if (empId.match(/^[1-9][0-9]{5}$/)) {
			return true;
		}
		else {
			vscode.window.showErrorMessage('Employee Id must be a six digit number starting with non-zero integer');
			vscode.window.showInformationMessage("Please Restart your extension");
			return false;
		}
	}
	else {
		vscode.window.showErrorMessage('No employee Id provided! Please Restart your extension');
		return false;
	}
}

validator.validatePassword = function (password) {
	if (password !== undefined && password.length > 0){
		return true;}
	else {
		vscode.window.showErrorMessage('No password provided! Please Restart your extension');
		return false;
	}
}

module.exports =validator;