const educator = {}
const vscode = require('vscode');

educator.logged = function () {
    vscode.window.showErrorMessage("Educator functionality missing.")
}

module.exports = educator;
