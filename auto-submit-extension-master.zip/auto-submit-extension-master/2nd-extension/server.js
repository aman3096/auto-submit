const express = require('express');
const fs = require('fs');
const cors = require('cors');
const uuid = require('node-uuid');
const httpContext = require('express-http-context')
const username = require("os").userInfo().username;
const multer = require('multer');
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, '/Users/' + username + '/Desktop/Submissions')
  },
  filename: function (req, file, cb) {
    console.log(file.originalname)
    let logMessage = file.originalname + " is received at " + new Date() + "\n"
    fs.appendFile('RequestLogger.txt', logMessage, (err) => {
      if (err)
        throw err;
    });
    cb(null, file.originalname)
  }
})
var upload = multer({ storage: storage })
// const upload = multer({
//   dest: 'uploads/' // this saves your file into a directory called "uploads"
// }); 
const app = express();
app.use(httpContext.middleware);
// Run the context for each request. Assign a unique identifier to each request
app.use(cors());
app.use(function (req, res, next) {
  httpContext.set('reqId', uuid.v1());
  next();
});

app.get('/success', (req, res) => {
  res.send("Submitted successfully!!!")
});

app.post('/', upload.single('file-to-upload'), (req, res) => {
  if (req.file !== undefined)
    res.redirect('/success');
  else
    res.send("Please select a file to submit")
});
app.listen(7000);
console.log("Server started at 7000");
module.exports = app