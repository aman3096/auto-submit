const axios = require('axios');
const URL = "http://localhost:3000/";
const fs = require('fs');
const vscode = require ('vscode');
const FormData = require ('form-data');
const a ={"data":"data"};
const File = require('file-class')
const fetch = require('node-fetch')
var info={};

info.getInfo = function () {
    return axios.get(URL + 'getInfo').then(response => {
        var arr = response.data;
        vscode.window.showInformationMessage("get");       
        return (arr);
    });
}
info.putInfo = function (empId) {
     return axios.put(URL + 'putInfo/'+empId , a ).then(response => {      
         return (response.data);
     });
}

info.postInfo = function (empId) {
    //  var f = new File(["asdf"], "file.txt", {type: "text/plain", lastModified: date});
    // vscode.window.showErrorMessage("there"+f);

    //  axios.post(URL+'postInfo'+empId, f).then(_=>vscode.window.showInformationMessage('post done'))
    // axiosFileUpload(rentURL + 'putInfo/'+empId, f).then(_=>vscode.window.showInformationMessage("hi"));

    // var form = new FormData();
    // form.append('file', './file.txt');
    // console.log(form);
    // form.submit(URL+'postInfo', (err,res)=>{vscode.window.showErrorMessage('a'+err+res)});
    //  axios.post(URL+'postInfo', form).then(_=>vscode.window.showErrorMessage('a'+_))
    return axios.put(URL + 'putInfo/'+empId , a ).then(response => {      
        return (response.data);
    });

}
module.exports =info;