const admin = {}
const vscode = require('vscode');

admin.logged = function () {
    vscode.window.showErrorMessage("Admin functionality missing.")
}

module.exports = admin;
