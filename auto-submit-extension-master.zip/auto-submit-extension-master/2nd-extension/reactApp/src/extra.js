const { exec } = require('child_process');
const child = ()=>{exec('npm start', "index.js" , (error, stdout, stderr) => {
    console.log("kooo")
if (error) {
    throw error;
}
console.log(stdout);
})};

module.exports = child;