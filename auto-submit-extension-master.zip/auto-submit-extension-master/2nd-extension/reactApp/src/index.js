import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Route } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";

class FileUpload extends React.Component {
  constructor() {
    super();
    this.state = {
      selectedFile: false
    }
  }
  onChange1 = (event) => {
    event.preventDefault();
    if (event.target.files !== undefined)
      this.setState({ selectedFile: true })
  }
  render() {
    return (
      <div className="AutoSubmit"><br />
        <div className="row">
          <div className="col-md-4 offset-4">
            <div className="card bg-light text-dark">
              <div className="card-header">
                <center>
                  <h4>AutoSubmit Exstension</h4>
                </center>
              </div>
              <div className="card-body text-left">
                <form className="form" action="http://GMYSL2005-089:7000/" enctype="multipart/form-data" name="asd" method="post">
                  <div className="form-group">
                  <input type="file" id="file" name="file-to-upload" onChange={this.onChange1} className="form-control-file" style={{borderRadius:"10px",border:"1px silver solid"}}/>
                    <br/>
                    <label>Select the zip folder with the name of your employee Id from your desktop</label>
                  </div>
                  <div className="form-group">
                  <br/>
                  <button type="submit" name="submitbtn" className="btn btn-success btn-lg btn-block" disabled={!this.state.selectedFile}>
                    Submit
                  </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

class AppComp extends React.Component {
  render() {
    return (
      <Router>
        <Route path='/' component={FileUpload} />
      </Router>
    )
  }
}

ReactDOM.render(<AppComp />, document.getElementById("root"))
