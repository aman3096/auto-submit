const login = {}
const vscode = require('vscode');
const validator = require('./validator');
const user = require('./user');

login.initiateLogin = function () {
    const items = ['User', 'Educator', 'Admin'];
    vscode.window.showQuickPick(items).then((selection) => {
        switch (selection) {
            case 'User': { userLogin(); break; }
            case 'Admin': { adminLogin(); break; }
            case 'Educator': { educatorLogin(); break; }
        }

    })
}

userLogin = function () {
    vscode.window.showInputBox({ prompt: "Enter your EmpId", placeHolder: "EmpId", password: false })
        .then((info) => {
            let empId = info;
            if (validator.validateEmpId(empId))
                vscode.window.showInputBox({ prompt: "Enter your Password", placeHolder: "Password", password: true })
                    .then((info) => {
                        if (validator.validatePassword(info)) {
                            vscode.window.setStatusBarMessage(empId);
                            (user.logged(empId));
                        }
                    });
        });
}

adminLogin = function () {
    admin.logged();
}

educatorLogin = function () {
    educator.logged();
}

module.exports = login;