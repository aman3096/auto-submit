var express = require('express');
var fs = require('fs');
var bodyParser = require('body-parser')
var app = express()

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())

app.use(bodyParser.json());

app.get('/getInfo', (req, res, next) => {
     console.log('get');
     res.send('bc');
})

app.put('/putInfo/:number', (req,res, next) => {
      console.log(req.params.number);
      console.log(req.body);
      fs.appendFile('RequestLogger.txt',req.params.number +' : '+ req.body + '\n', (err) => {
            if (err)
              throw err;
          });
      res.send('Succesfully submitted');
})

app.listen(3000);
console.log("Server listening in port 3000");